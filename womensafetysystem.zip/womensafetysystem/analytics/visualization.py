import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import geopandas as gpd
from shapely.geometry import Point, Polygon

# Load incident data (CSV or database connection)
# Replace with actual path if using CSV or connect to MongoDB/Database
incident_data = pd.read_csv('incidents.csv')

# Ensure that the 'timestamp' is a datetime object
incident_data['timestamp'] = pd.to_datetime(incident_data['timestamp'])

# 1. INCIDENTS OVER TIME (trend analysis)
def plot_incidents_over_time():
    incident_data['date'] = incident_data['timestamp'].dt.date
    incidents_per_day = incident_data.groupby('date').size()

    plt.figure(figsize=(10, 6))
    incidents_per_day.plot(kind='line', marker='o', color='b')
    plt.title('Incidents Over Time')
    plt.xlabel('Date')
    plt.ylabel('Number of Incidents')
    plt.grid(True)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

# 2. INCIDENT TYPES DISTRIBUTION (bar chart)
def plot_incident_types_distribution():
    incident_types = incident_data['type'].value_counts()

    plt.figure(figsize=(8, 5))
    sns.barplot(x=incident_types.index, y=incident_types.values, palette='viridis')
    plt.title('Incident Types Distribution')
    plt.xlabel('Incident Type')
    plt.ylabel('Frequency')
    plt.tight_layout()
    plt.show()

# 3. GEOGRAPHICAL HOTSPOTS (heatmap based on lat/lng)
def plot_geographical_hotspots():
    # Create a GeoDataFrame for visualization
    geometry = [Point(xy) for xy in zip(incident_data['location.lng'], incident_data['location.lat'])]
    geo_df = gpd.GeoDataFrame(incident_data, geometry=geometry)

    # World map (or you can replace with a city-specific polygon if needed)
    world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))

    plt.figure(figsize=(10, 6))
    base = world.plot(figsize=(10, 6), color='lightgray')
    geo_df.plot(ax=base, marker='o', color='red', alpha=0.5, markersize=5)
    plt.title('Geographical Hotspots of Incidents')
    plt.tight_layout()
    plt.show()

# 4. INCIDENTS BY HOUR (distribution of incidents during the day)
def plot_incidents_by_hour():
    incident_data['hour'] = incident_data['timestamp'].dt.hour
    incidents_by_hour = incident_data.groupby('hour').size()

    plt.figure(figsize=(10, 6))
    incidents_by_hour.plot(kind='bar', color='coral')
    plt.title('Incidents by Hour of the Day')
    plt.xlabel('Hour')
    plt.ylabel('Number of Incidents')
    plt.tight_layout()
    plt.show()

# 5. INCIDENT STATUS (pie chart for resolved vs unresolved)
def plot_incident_status():
    incident_status = incident_data['status'].value_counts()

    plt.figure(figsize=(6, 6))
    incident_status.plot(kind='pie', autopct='%1.1f%%', startangle=90, colors=['#66b3ff', '#99ff99'])
    plt.title('Incident Status: Resolved vs Pending')
    plt.ylabel('')
    plt.tight_layout()
    plt.show()

# Call the functions to generate the plots
plot_incidents_over_time()
plot_incident_types_distribution()
plot_geographical_hotspots()
plot_incidents_by_hour()
plot_incident_status()
