import cv2
import numpy as np
from tensorflow.keras.models import load_model

# Load pre-trained gesture detection model
model = load_model('gesture_model.h5')

cap = cv2.VideoCapture(0)  # Use the webcam

while True:
    ret, frame = cap.read()
    if not ret:
        break
    
    # Preprocess the frame and make predictions
    # Assuming the frame contains gesture data like SOS signals
    prediction = model.predict(np.expand_dims(frame, axis=0))
    if prediction == 1:  # Detected SOS signal
        print("SOS detected!")
        # Send alert (e.g., via Twilio or email)
    
cap.release()
cv2.destroyAllWindows()
