const Incident = require('../models/Incident');

// Create a new incident
exports.createIncident = async (req, res) => {
  const { userId, type, location, description } = req.body;

  try {
    const newIncident = new Incident({
      userId,
      type,
      location,
      description,
      createdAt: new Date(),
    });

    await newIncident.save();
    res.status(201).json(newIncident);
  } catch (error) {
    res.status(500).json({ message: 'Error creating incident', error });
  }
};

// Get all incidents
exports.getIncidents = async (req, res) => {
  try {
    const incidents = await Incident.find().populate('userId', 'name');
    res.status(200).json(incidents);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching incidents', error });
  }
};
