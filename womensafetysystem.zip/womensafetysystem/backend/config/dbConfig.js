module.exports = {
    DB_URI: 'mongodb://localhost:27017/women-safety-db', // MongoDB URI
  };
  