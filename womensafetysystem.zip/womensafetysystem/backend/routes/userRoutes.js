const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

// POST route for creating a user
router.post('/', userController.createUser);

// GET route for fetching all users
router.get('/', userController.getUsers);

module.exports = router;
