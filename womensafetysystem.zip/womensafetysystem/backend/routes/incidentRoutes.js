const express = require('express');
const router = express.Router();
const incidentController = require('../controllers/incidentController');

// POST route for creating an incident
router.post('/', incidentController.createIncident);

// GET route for fetching all incidents
router.get('/', incidentController.getIncidents);

module.exports = router;
