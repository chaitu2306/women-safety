const express = require('express');
const app = express();

// Routes
const incidentRoutes = require('./routes/incidentRoutes');
const userRoutes = require('./routes/userRoutes');

// Use Routes
app.use('/api/incidents', incidentRoutes);
app.use('/api/users', userRoutes);

module.exports = app;
