const mongoose = require('mongoose');

// User Schema: Stores information about users
const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  emergencyContacts: {
    type: [String], // List of phone numbers of emergency contacts
    default: [],
  },
});

// Incident Schema: Stores information about incidents
const IncidentSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // Reference to User
  type: {
    type: String,
    required: true,
    enum: ['SOS', 'Anomaly', 'Normal'],
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  location: {
    lat: {
      type: Number,
      required: true,
    },
    lng: {
      type: Number,
      required: true,
    },
  },
  description: {
    type: String,
    required: true,
  },
  status: {
    type: String,
    enum: ['Pending', 'Resolved'],
    default: 'Pending',
  },
});

// Export models for usage in other files
module.exports = {
  User: mongoose.model('User', UserSchema),
  Incident: mongoose.model('Incident', IncidentSchema),
};
