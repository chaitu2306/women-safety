const mongoose = require('mongoose');
const { User, Incident } = require('./schema');

// Connect to MongoDB (make sure MongoDB is running locally or replace the connection URL with your MongoDB Atlas URL)
mongoose.connect('mongodb://localhost:27017/women_safety', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useCreateIndex: true,
})
.then(() => {
  console.log('Connected to MongoDB');
  seedDatabase();
})
.catch((err) => {
  console.error('Error connecting to MongoDB', err);
});

// Seed function to insert sample data into the database
async function seedDatabase() {
  try {
    // Create sample users
    const user1 = new User({
      name: 'Alice Johnson',
      phone: '1234567890',
      email: 'alice@example.com',
      emergencyContacts: ['0987654321', '1122334455'],
    });

    const user2 = new User({
      name: 'Maria Clark',
      phone: '9876543210',
      email: 'maria@example.com',
      emergencyContacts: ['2233445566', '4455667788'],
    });

    // Save users to the database
    await user1.save();
    await user2.save();

    console.log('Sample users created');

    // Create sample incidents for user1 and user2
    const incident1 = new Incident({
      user: user1._id,
      type: 'SOS',
      location: { lat: 12.9716, lng: 77.5946 },
      description: 'Emergency alert from Alice',
    });

    const incident2 = new Incident({
      user: user2._id,
      type: 'Anomaly',
      location: { lat: 13.0827, lng: 80.2707 },
      description: 'Suspicious activity detected near Maria',
    });

    // Save incidents to the database
    await incident1.save();
    await incident2.save();

    console.log('Sample incidents created');
    
    // Close the database connection after seeding
    mongoose.connection.close();
  } catch (error) {
    console.error('Error seeding the database:', error);
  }
}
